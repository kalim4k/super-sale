import React, { useState } from "react";
import { QuizState } from "./types";
import { motion, AnimatePresence } from "motion/react";
import { 
  ChevronRight, 
  ArrowLeft, 
  RotateCcw,
  ShieldCheck
} from "lucide-react";
import VisitorChatWidget from "./components/VisitorChatWidget";
import AdminPanel from "./components/AdminPanel";

const INITIAL_STATE: QuizState = {
  age: "",
  country: "",
  wantsAmira: "",
  wantsAmiraContacts: "",
  wantsCatalogue: "",
  step: 1, // Start directly with the first question
};

export default function App() {
  const [state, setState] = useState<QuizState>(INITIAL_STATE);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [enteredCode, setEnteredCode] = useState("");
  const [codeError, setCodeError] = useState("");
  const [copiedLockCode, setCopiedLockCode] = useState(false);

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    const code = enteredCode.trim().toUpperCase();
    if (code === "M2026") {
      setIsUnlocked(true);
      setIsAdmin(false);
      setCodeError("");
    } else if (code === "KADMIN2026") {
      setIsUnlocked(true);
      setIsAdmin(true);
      setCodeError("");
    } else {
      setCodeError("Code d'accès incorrect. Veuillez réessayer.");
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText("M2026");
    setCopiedLockCode(true);
    setTimeout(() => setCopiedLockCode(false), 2000);
  };

  const handleSelectOption = (field: keyof QuizState, value: string) => {
    setState((prev) => ({
      ...prev,
      [field]: value,
      step: prev.step + 1,
    }));
  };

  const handlePrevStep = () => {
    if (state.step > 1) {
      setState((prev) => ({
        ...prev,
        step: prev.step - 1,
      }));
    }
  };

  const handleRestart = () => {
    setState(INITIAL_STATE);
  };

  // Progress Percentage
  const progressPercent = Math.min(((state.step - 1) / 5) * 100, 100);

  if (!isUnlocked) {
    return (
      <div className="relative flex min-h-screen w-full max-w-full overflow-x-hidden flex-col items-center justify-start bg-[#f8f9fa] px-4 py-6 text-slate-800 font-sans selection:bg-blue-500/30">
        <div className="w-full max-w-[440px] my-auto bg-white rounded-[28px] border border-slate-100 shadow-xl p-5 sm:p-8 md:p-10 flex flex-col items-center animate-fade-in" id="lock-card">
          
          {/* Avatar frame with Amira's photo */}
          <div className="flex justify-center mb-4">
            <div className="h-20 w-20 overflow-hidden rounded-2xl border-2 border-slate-100 bg-slate-50 shadow-md">
              <img
                src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/7ecf9fc5-15b1-431a-95c7-f1b94ce68728.png"
                alt="Amira Profile"
                className="h-full w-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Title */}
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 uppercase tracking-tight text-center">
            ESPACE BIZI
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-500 font-medium text-center">
            Mettre le code dans la vidéo pour accéder
          </p>

          <div className="w-full border-b border-slate-100/80 my-6" />

          {/* Info code box matching screenshot layout */}
          <div className="w-full bg-[#fcf9f9] border border-[#f5eded] rounded-2xl p-5 flex flex-col items-center justify-center text-center">
            <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase mb-2">
              VOTRE CODE D'ACCÈS
            </span>
            <div className="flex items-center gap-3">
              <div className="bg-[#eff6ff] text-[#2563eb] px-4 py-1.5 rounded-lg text-sm sm:text-base font-extrabold tracking-widest border border-[#dbeafe]/80">
                M2026
              </div>
              <button
                type="button"
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition shadow-sm active:scale-95 cursor-pointer"
              >
                {copiedLockCode ? (
                  <span className="text-green-600 font-bold">Copié!</span>
                ) : (
                  <>
                    <svg className="h-3.5 w-3.5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                    </svg>
                    <span>Copier</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Input Form */}
          <form onSubmit={handleVerifyCode} className="w-full mt-6 space-y-4">
            <div>
              <label htmlFor="access-code-input" className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-2">
                CODE D'ACCÈS
              </label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <input
                  id="access-code-input"
                  type="text"
                  placeholder="Saisir le code..."
                  value={enteredCode}
                  onChange={(e) => {
                    setEnteredCode(e.target.value);
                    if (codeError) setCodeError("");
                  }}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-3 text-sm text-slate-900 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-none transition-all"
                />
              </div>
              {codeError && (
                <p className="mt-1.5 text-xs text-rose-600 font-medium flex items-center gap-1">
                  <span>⚠️</span> {codeError}
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-[#2563eb] hover:bg-[#1d4ed8] text-white py-3.5 text-sm font-bold shadow-lg shadow-blue-500/15 transition-all duration-150 active:scale-[0.98]"
            >
              <span>Accéder</span>
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </form>

          <div className="w-full border-b border-slate-100/80 my-6" />

          {/* Secure SSL indicator */}
          <div className="flex items-center justify-center gap-2 text-[10px] text-slate-400 font-black tracking-widest uppercase">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>ACCÈS SÉCURISÉ SSL</span>
          </div>

        </div>
      </div>
    );
  }

  if (isUnlocked && isAdmin) {
    return (
      <div className="relative flex min-h-screen w-full max-w-full overflow-x-hidden flex-col items-center justify-center bg-slate-950 px-4 py-6 text-slate-100 font-sans selection:bg-rose-500/30">
        <AdminPanel
          onLogout={() => {
            setIsAdmin(false);
            setIsUnlocked(false);
            setEnteredCode("");
          }}
        />
      </div>
    );
  }

  return (
    <div className={`relative flex min-h-screen w-full max-w-full overflow-x-hidden flex-col items-center justify-start bg-slate-950 px-4 py-6 text-slate-100 font-sans selection:bg-rose-500/30 selection:text-white ${state.step === 6 ? "pb-28 sm:pb-32" : ""}`}>
      {/* Decorative gradient background blur */}
      <div className="absolute -top-40 left-1/2 -z-10 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-rose-500/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 -z-10 h-[300px] w-[300px] rounded-full bg-rose-600/5 blur-[100px] pointer-events-none" />

      {/* Main Single Card Panel */}
      <div className="w-full max-w-lg my-auto flex flex-col" id="quiz-card-container">
        
        {/* Progress bar (only during the quiz, step 1 to 5) */}
        {state.step <= 5 && (
          <div className="mb-6">
            <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-slate-500">
              <span>Filtre d'accès</span>
              <span className="text-rose-500 font-bold">Étape {state.step} / 5</span>
            </div>
            <div className="mt-2 h-1 w-full rounded-full bg-slate-900 overflow-hidden border border-slate-800/20">
              <div
                className="h-full rounded-full bg-gradient-to-r from-rose-600 to-rose-400 transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        )}

        <AnimatePresence mode="wait">
          {/* STEP 1: AGE */}
          {state.step === 1 && (
            <motion.div
              key="step-1"
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -10 }}
              transition={{ duration: 0.25 }}
              className="w-full rounded-3xl border border-slate-900 bg-slate-950/60 p-5 sm:p-8 md:p-10 shadow-2xl backdrop-blur-md"
              id="step-age"
            >
              <h1 className="text-center font-display text-lg sm:text-2xl md:text-3xl font-bold tracking-tight text-white">
                Quel est votre âge ?
              </h1>
              <p className="mt-2 text-center text-xs text-slate-400">
                Veuillez sélectionner votre tranche d'âge pour continuer.
              </p>

              <div className="mt-8 space-y-3">
                {[
                  { label: "18-25 ans", value: "18-25 ans" },
                  { label: "26-35 ans", value: "26-35 ans" },
                  { label: "plus de 36 ans", value: "plus de 36 ans" },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => handleSelectOption("age", opt.value)}
                    className="flex w-full items-center justify-between rounded-2xl border border-slate-800/80 bg-slate-900/35 px-5 py-4 text-sm font-semibold text-slate-200 transition-all duration-200 hover:border-rose-500/30 hover:bg-slate-900/80 hover:text-white"
                  >
                    <span>{opt.label}</span>
                    <ChevronRight className="h-4 w-4 text-slate-500" />
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {/* STEP 2: COUNTRY */}
          {state.step === 2 && (
            <motion.div
              key="step-2"
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -10 }}
              transition={{ duration: 0.25 }}
              className="w-full rounded-3xl border border-slate-900 bg-slate-950/60 p-5 sm:p-8 md:p-10 shadow-2xl backdrop-blur-md"
              id="step-country"
            >
              <div className="flex items-center justify-between">
                <button
                  onClick={handlePrevStep}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-white transition"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  <span>Retour</span>
                </button>
              </div>

              <div className="mt-5 overflow-hidden rounded-2xl border border-slate-800/80 shadow-lg">
                <img
                  src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/76cad39d-ac23-4be6-b75a-ccdd4c33a47f.png"
                  alt="Club Amira Banner"
                  className="w-full h-auto object-cover max-h-40 sm:max-h-64"
                  referrerPolicy="no-referrer"
                />
              </div>

              <h1 className="mt-5 text-center font-display text-lg sm:text-2xl md:text-3xl font-bold tracking-tight text-white">
                Quel est votre pays ?
              </h1>
              <p className="mt-2 text-center text-xs text-slate-400">
                Sélectionnez votre localisation pour obtenir les bons contacts.
              </p>

              <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  { label: "Togo 🇹🇬", value: "Togo" },
                  { label: "Benin 🇧🇯", value: "Benin" },
                  { label: "Côte d'ivoire 🇨🇮", value: "Côte d'ivoire" },
                  { label: "Cameroun 🇨🇲", value: "Cameroun" },
                  { label: "Senegal 🇸🇳", value: "Senegal" },
                  { label: "Burkina Faso 🇧🇫", value: "Burkina Faso" },
                  { label: "Niger 🇳🇪", value: "Niger" },
                  { label: "Autre 🌍", value: "Autre" },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => handleSelectOption("country", opt.value)}
                    className="flex items-center justify-between rounded-xl border border-slate-800/80 bg-slate-900/35 px-4 py-3.5 text-xs sm:text-sm font-semibold text-slate-200 transition-all duration-200 hover:border-rose-500/30 hover:bg-slate-900/80 hover:text-white"
                  >
                    <span>{opt.label}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {/* STEP 3: AMIRA'S DIRECT OFFER */}
          {state.step === 3 && (
            <motion.div
              key="step-3"
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -10 }}
              transition={{ duration: 0.25 }}
              className="w-full rounded-3xl border border-slate-900 bg-slate-950/60 p-5 sm:p-8 md:p-10 shadow-2xl backdrop-blur-md"
              id="step-amira-offer"
            >
              <div className="flex items-center justify-between">
                <button
                  onClick={handlePrevStep}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-white transition"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  <span>Retour</span>
                </button>
              </div>

              {/* Conversational Avatar Design */}
              <div className="mt-4 flex flex-col items-center">
                <div className="relative">
                  <div className="h-24 w-24 sm:h-28 sm:w-28 overflow-hidden rounded-full border-2 border-rose-500 bg-slate-900 shadow-xl">
                    <img
                      src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/7ecf9fc5-15b1-431a-95c7-f1b94ce68728.png"
                      alt="Amira"
                      className="h-full w-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className="absolute bottom-1 right-1 h-4 w-4 sm:h-5 sm:w-5 rounded-full bg-green-500 ring-2 ring-slate-950" />
                </div>
                <span className="mt-2.5 text-xs font-bold text-green-400">Amira est en ligne</span>
              </div>

              <h2 className="mt-5 text-center font-sans text-sm sm:text-base md:text-lg font-medium leading-relaxed text-slate-100 px-2">
                Je suis Amira, je te propose un mougouli à 7000f? voulez vous son numéro WhatsApp ?
              </h2>

              <div className="mt-8 space-y-3">
                <button
                  onClick={() => handleSelectOption("wantsAmira", "OUI")}
                  className="flex w-full items-center justify-center rounded-2xl border border-slate-800 bg-slate-900/40 py-4 text-sm font-bold text-slate-200 transition-all hover:border-slate-700 hover:bg-slate-900"
                >
                  OUI
                </button>
                <button
                  onClick={() => handleSelectOption("wantsAmira", "JE SUIS CHAUD")}
                  className="flex w-full items-center justify-center rounded-2xl bg-gradient-to-r from-rose-600 to-rose-500 py-4 text-sm font-black text-white shadow-lg shadow-rose-950/40 transition hover:from-rose-500 hover:to-rose-400"
                >
                  JE SUIS CHAUD
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 4: AMIRA 2500F OFFER */}
          {state.step === 4 && (
            <motion.div
              key="step-4"
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -10 }}
              transition={{ duration: 0.25 }}
              className="w-full rounded-3xl border border-slate-900 bg-slate-950/80 p-5 sm:p-7 md:p-8 shadow-2xl backdrop-blur-md relative overflow-hidden"
              id="step-amira-2500"
            >
              {/* Decorative light ring */}
              <div className="absolute -right-20 -top-20 h-40 w-40 rounded-full bg-rose-500/10 blur-2xl pointer-events-none" />

              <div className="flex items-center justify-between relative z-10">
                <button
                  onClick={handlePrevStep}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-white transition"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  <span>Retour</span>
                </button>
                <span className="bg-rose-500/15 border border-rose-500/30 text-rose-400 text-[10px] font-extrabold uppercase tracking-widest px-3 py-1 rounded-full">
                  Offre Exclusive
                </span>
              </div>

              {/* Conversational Avatar Design */}
              <div className="mt-4 flex flex-col items-center relative z-10">
                <div className="relative">
                  <div className="h-20 w-20 sm:h-24 sm:w-24 overflow-hidden rounded-full border-2 border-rose-500 bg-slate-900 shadow-xl">
                    <img
                      src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/7ecf9fc5-15b1-431a-95c7-f1b94ce68728.png"
                      alt="Amira"
                      className="h-full w-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className="absolute bottom-1 right-1 h-3.5 w-3.5 sm:h-4 sm:w-4 rounded-full bg-green-500 ring-2 ring-slate-950 animate-pulse" />
                </div>
                <span className="mt-2 text-xs font-bold text-green-400 flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 inline-block animate-ping" />
                  Amira est en ligne
                </span>
              </div>

              {/* Main Pitch Card */}
              <div className="mt-5 text-center relative z-10">
                <p className="text-xs uppercase tracking-wider text-rose-400 font-bold">ACCÈS PRIVÉ DEUX-EN-UN</p>
                
                {/* Big pricing callout */}
                <div className="mt-2 bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-4 shadow-inner">
                  <span className="text-xs text-slate-400 block uppercase font-bold tracking-wider">Tarif unique d'accès</span>
                  <div className="text-3xl sm:text-4xl font-black text-rose-500 mt-1 flex items-center justify-center gap-1.5">
                    2 500 <span className="text-xl font-bold text-slate-200">FCFA</span>
                  </div>
                  <span className="text-[11px] text-slate-500 block mt-1">Frais uniques • Aucun abonnement caché</span>
                </div>
              </div>

              {/* Bulleted checklist */}
              <div className="mt-6 space-y-4 bg-slate-900/40 border border-slate-900/50 rounded-2xl p-4 relative z-10">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Ce que vous obtenez immédiatement :</h3>
                
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-green-500/10 text-green-400">
                    <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm text-slate-200 font-bold">Mon numéro WhatsApp personnel (Amira)</p>
                    <p className="text-xs text-slate-400 mt-0.5">Pour s'appeler, s'écrire et convenir d'un rendez-vous direct.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-green-500/10 text-green-400">
                    <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm text-slate-200 font-bold">Le numéro de +150 autres filles sexy</p>
                    <p className="text-xs text-slate-400 mt-0.5">Le répertoire complet des "go" les plus chaudes de ta région.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-green-500/10 text-green-400">
                    <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm text-slate-200 font-bold">Disponibles pour "mougouli" (rencontres)</p>
                    <p className="text-xs text-slate-400 mt-0.5">Pas de blabla inutile, des relations directes, réelles et sans protocole.</p>
                  </div>
                </div>

                {/* Country Badges */}
                <div className="pt-2 border-t border-slate-800/60">
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-2">Pays disponibles :</p>
                  <div className="flex flex-wrap gap-1.5">
                    <span className="bg-slate-950 px-2 py-1 rounded text-xs text-slate-300 font-medium border border-slate-800">Togo 🇹🇬</span>
                    <span className="bg-slate-950 px-2 py-1 rounded text-xs text-slate-300 font-medium border border-slate-800">Bénin 🇧🇯</span>
                    <span className="bg-slate-950 px-2 py-1 rounded text-xs text-slate-300 font-medium border border-slate-800">Cameroun 🇨🇲</span>
                    <span className="bg-slate-950 px-2 py-1 rounded text-xs text-slate-300 font-medium border border-slate-800">Côte d'Ivoire 🇨🇮</span>
                    <span className="bg-slate-950 px-2 py-1 rounded text-xs text-slate-300 font-medium border border-slate-800">Burkina 🇧🇫</span>
                    <span className="bg-slate-950 px-2 py-1 rounded text-xs text-slate-300 font-medium border border-slate-800">Sénégal 🇸🇳</span>
                  </div>
                </div>
              </div>

              {/* CTA Reassurance Note */}
              <div className="mt-4 flex items-center gap-2 px-1 text-[11px] text-rose-400/90 font-medium justify-center relative z-10">
                <svg className="h-4 w-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
                <span>Paiement facile par Mobile Money à l'étape suivante !</span>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 space-y-2.5 relative z-10">
                <button
                  onClick={() => handleSelectOption("wantsAmiraContacts", "OUI")}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-rose-600 to-rose-500 py-4 text-sm font-black text-white shadow-lg shadow-rose-950/40 transition hover:from-rose-500 hover:to-rose-400 active:scale-98 cursor-pointer relative overflow-hidden group"
                >
                  {/* Subtle pulsing background highlight */}
                  <span className="absolute inset-0 w-full h-full bg-white/10 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ease-out" />
                  <span>OUI, JE VEUX ACCÉDER MAINTENANT !</span>
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                  </svg>
                </button>

                <button
                  onClick={() => handleSelectOption("wantsAmiraContacts", "NON")}
                  className="flex w-full items-center justify-center py-2 text-xs font-semibold text-slate-500 hover:text-slate-300 transition cursor-pointer"
                >
                  Non, je ne suis pas intéressé
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 5: CATALOGUE OFFER */}
          {state.step === 5 && (
            <motion.div
              key="step-5"
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -10 }}
              transition={{ duration: 0.25 }}
              className="w-full rounded-3xl border border-slate-900 bg-slate-950/60 p-4 sm:p-8 md:p-10 shadow-2xl backdrop-blur-md"
              id="step-catalogue-offer"
            >
              <div className="flex items-center justify-between">
                <button
                  onClick={handlePrevStep}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-white transition"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  <span>Retour</span>
                </button>
              </div>

              {/* Deux images l'une à côté de l'autre */}
              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="overflow-hidden rounded-2xl border border-slate-900/60 shadow-lg aspect-[4/5]">
                  <img
                    src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/18f408a9-879d-4629-ab6f-bb245d6830ea.jpg"
                    alt="Aperçu Catalogue 1"
                    className="h-full w-full object-cover hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="overflow-hidden rounded-2xl border border-slate-900/60 shadow-lg aspect-[4/5]">
                  <img
                    src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/8b3c6e8c-bd9c-49e7-9b6f-01df5166e808.jpg"
                    alt="Aperçu Catalogue 2"
                    className="h-full w-full object-cover hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>

              <div className="mt-4 overflow-hidden border border-slate-900 shadow-md">
                <img
                  src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/a54a78c4-d777-45cb-939a-69ce5e28e28c.png"
                  alt="Aperçu VIP"
                  className="w-full h-auto block"
                  referrerPolicy="no-referrer"
                />
              </div>

              <h2 className="mt-4 text-center font-sans text-xs sm:text-sm md:text-base font-medium leading-relaxed text-slate-200">
                Dans ce cas je vous propose aussi un catalogue complet de plus de 100 numéros WhatsApp de kpoclé que tu peux appeler pour mougouli;
                tu es intéressé ?
              </h2>

              <div className="mt-8 space-y-3">
                <button
                  onClick={() => handleSelectOption("wantsCatalogue", "OUI")}
                  className="flex w-full items-center justify-center rounded-2xl border border-slate-800 bg-slate-900/40 py-4 text-sm font-bold text-slate-200 transition-all hover:border-slate-700 hover:bg-slate-900 cursor-pointer"
                >
                  OUI
                </button>
                <button
                  onClick={() => handleSelectOption("wantsCatalogue", "Bien sur")}
                  className="flex w-full items-center justify-center rounded-2xl bg-gradient-to-r from-rose-600 to-rose-500 py-4 text-sm font-black text-white shadow-lg shadow-rose-950/40 transition hover:from-rose-500 hover:to-rose-400 cursor-pointer"
                >
                  Bien sur
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 6: FINAL OFFER & CHECKOUT */}
          {state.step === 6 && (
            <motion.div
              key="step-6"
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -10 }}
              transition={{ duration: 0.3 }}
              className="w-full rounded-3xl border border-slate-900 bg-slate-950/65 p-4 sm:p-8 md:p-10 shadow-2xl backdrop-blur-md"
              id="step-final-checkout"
            >
              <div className="mb-5 overflow-hidden border border-slate-900 shadow-md">
                <img
                  src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/a54a78c4-d777-45cb-939a-69ce5e28e28c.png"
                  alt="Aperçu Catalogue VIP"
                  className="w-full h-auto block"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Copy part 1 */}
              <p className="text-center text-xs sm:text-sm md:text-base font-bold text-white leading-relaxed">
                Parfait, voici le catalogue que j'ai préparé pour toi. Ya mon numéro dedans avec plus de 150 kpoklé de (Togo, Bénin, côte d'ivoire, Senegal, Burkina Faso, Mali, Cameroun, Niger…)
              </p>

              {/* trust badge image */}
              <div className="mt-4 flex justify-center w-full">
                <img
                  src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/a226fcac-e7a5-4f22-87f9-213ae88f60f7.svg"
                  alt="Badge de confiance"
                  className="h-10 max-w-[180px] w-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Copy part 2 */}
              <div className="mt-4 rounded-2xl bg-rose-950/15 border border-rose-900/20 p-4 text-center text-[11px] sm:text-xs text-rose-300 leading-relaxed font-medium">
                "C'est satisfait ou remboursé, y a mon numéro dedans, donc si tu n'es pas intéressé, tu m'écris et je te rembourse ton jeton."
              </div>

              {/* Extra proof and catalog previews */}
              <div className="mt-5 overflow-hidden border border-slate-900 shadow-md">
                <img
                  src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/dc6eeb02-eb26-4350-af48-f6dcf52ca912.jpg"
                  alt="Aperçu Catalogue 1"
                  className="w-full h-auto block"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="mt-4 overflow-hidden border border-slate-900 shadow-md">
                <img
                  src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/396a07d4-432a-4ed5-b8a1-25a004fccaae.jpg"
                  alt="Aperçu Catalogue 2"
                  className="w-full h-auto block"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="mt-4 overflow-hidden border border-slate-900 shadow-md">
                <img
                  src="https://ysbiedwkakdqadxtuwab.supabase.co/storage/v1/object/public/uploads/6be5bde1-01aa-4bae-af3c-e8451119a8d0.png"
                  alt="Aperçu Catalogue 3"
                  className="w-full h-auto block"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Action area */}
              <div className="mt-8 space-y-4">
                <a
                  href="https://izimomo.vercel.app/pay"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full text-center rounded-2xl bg-gradient-to-r from-rose-600 via-rose-500 to-rose-400 py-4.5 text-sm font-black uppercase tracking-wider text-white shadow-xl shadow-rose-950/60 transition hover:from-rose-500 hover:to-rose-300"
                  id="buy-button"
                >
                  ACHETER LE CATALOGUE
                </a>

                <button
                  onClick={handleRestart}
                  className="flex w-full items-center justify-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 transition"
                >
                  <RotateCcw className="h-3 w-3" />
                  Recommencer le quiz
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Discretion badge at the bottom */}
      <div className="mt-8 text-center text-[10px] text-slate-600 flex items-center justify-center gap-1 pointer-events-none">
        <ShieldCheck className="h-3.5 w-3.5 text-slate-700" />
        <span>Tunnel de sélection d'accès strictement privé et réservé aux adultes de 18 ans et plus.</span>
      </div>

      {/* Sticky Floating Bottom CTA for Step 6 */}
      {state.step === 6 && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.3 }}
          className="fixed bottom-0 left-0 right-0 z-50 border-t border-slate-900/80 bg-slate-950/90 px-4 py-4 shadow-[0_-15px_35px_rgba(0,0,0,0.8)] backdrop-blur-lg flex justify-center items-center"
        >
          <div className="w-full max-w-md">
            <a
              href="https://izimomo.vercel.app/pay"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full text-center rounded-2xl bg-gradient-to-r from-rose-600 via-rose-500 to-rose-400 py-4 text-xs sm:text-sm font-black uppercase tracking-wider text-white shadow-xl shadow-rose-950/60 transition active:scale-98 hover:from-rose-500 hover:to-rose-300"
            >
              ACHETER LE CATALOGUE
            </a>
          </div>
        </motion.div>
      )}

      {/* Floating Real-Time Visitor Chat Widget */}
      <VisitorChatWidget age={state.age} country={state.country} />
    </div>
  );
}
